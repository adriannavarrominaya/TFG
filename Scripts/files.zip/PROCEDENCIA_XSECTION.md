# PROCEDENCIA_XSECTION.md — colapso de 211 grupos (Fase 1 del runbook)

Certificado de procedencia del `XSECTION.dat` usado para reproducir el
Experimento 1 de Haffner, Miller & Morris, *Appl. Radiat. Isot.* **151** (2019)
52–61. Regla aplicada: ningún valor sin fuente citable.

Estado: **1.1 cerrado · 1.2 cerrado con reserva · 1.3 cerrado · 1.4 pendiente de
la ejecución de COLLAPS con la malla real.**

---

## 1.1 Librería de secciones eficaces

| Campo | Valor | Fuente |
|---|---|---|
| Fichero | `TENDL_ACT_211_EAFisot.zip` → `XSBL.dat` (44 493 063 B, 9-dic-2019) | descarga |
| URL | `https://www.oecd-nea.org/dbdata/jeff/jeff33/downloads/TENDL_ACT_211_EAFisot.zip` | usuario |
| Fecha de descarga | 8 de mayo *(año pendiente de confirmar)* | usuario |
| SHA-256 `XSBL.zip` | `ce18f91468fc4c9eff80e56cb7ac57d8d15c497d88ccf6a3e92e02dbbb545aba` | calculado |
| SHA-256 `XSBL.dat` | `0b7841a3db440506d40bc68671a858a91e47f0663cbd28b5438f2dc13ccdc23b` | calculado |
| Evaluación | **TENDL-2017**, puntual, generada con TALYS-1.9; para H, He, Li, Be, B, C, N, O, F, Th-232, U-233/235/238, Pu-239 se usó la TENDL-2017 general (ENDF) | cabecera de `XSBL.dat`, líneas 1–15 |
| Procesado | NJOY99.396, **función de peso plana**, estructura VITAMIN-J de 211 grupos, T = 293,16 K | cabecera de `XSBL.dat` |
| Contenido | 810 isótopos, 55 533 reacciones | cabecera de `XSBL.dat` |
| Autores del procesado | F. Ogando, P. Sauvan (UNED), 9-dic-2019 | cabecera de `XSBL.dat` |
| `ILIB` correspondiente | **12** = Vitamin-J+ (211 grupos) | manual ACAB v.2008, COLL.inp tarjeta 1, p. 29 |

**Precisión necesaria sobre la atribución.** El fichero se distribuye desde el
área de descargas de **JEFF-3.3** del OECD-NEA, pero su contenido declara ser
**TENDL-2017**. La redacción correcta es «librería TENDL-2017 en formato EAF,
211 grupos, distribuida a través del área JEFF-3.3 del OECD-NEA». La atribución
«JEFF-3.3.1» que aparecía en la versión 1 del script de flujo **no está
respaldada por la cabecera del fichero** y se ha eliminado.

**Etiqueta por reacción.** El `XSECTION.dat` conserva bajo cada reacción la línea
de procedencia individual, p. ej. para el `521300 1020`:
`TALYS-1.9  n + 130Te : (n,g)  Level 0`. Verificado.

---

## 1.2 Malla de energía — VERIFICACIÓN CRÍTICA

### Fuente adoptada

Estructura **VITAMIN-J+ de 211 grupos**, fronteras tomadas de:

> ENEA, informe técnico **ADPFISS-LP1-107**, Tabla 2, *«Energy group boundaries
> of the Vitamin-J+ (211-energy group structure)»*.
> `https://iris.enea.it/retrieve/dd11e37c-dbb1-5d97-e053-d805fe0a6f04/ADPFISS-LP1-107.pdf`

Copia de trabajo: `vitaminj_plus_211_eV.txt`
(SHA-256 `4c69bd5d740ab652ae064a24f0f3b9466311055037c438da64a2fd75a0e955f8`).

**Escala.** La columna de la tabla original está escalada respecto de las
unidades físicas: sus valores multiplicados por 10⁻⁴ dan eV (equivalentemente,
por 10⁻¹⁰ dan MeV). El factor se ha determinado y verificado por tres vías
independientes (controles A, B y C). El fichero de trabajo está en eV.

**Extremos resultantes:** grupo 1 = [54; 55] MeV · grupo 211 = [10⁻⁵; 0,1] eV.

### Controles pasados

**A — contra el manual ACAB (independiente de la librería).** La estructura de
211 grupos es la VITAMIN-J de 175 grupos extendida hasta 55 MeV con 36 grupos de
1 MeV entre 20 y 55 MeV (manual v.2008, p. 26). De ahí, la correspondencia
grupo VITAMIN-J *n* ↔ grupo VITAMIN-J+ *g = n + 36*. Comparadas las **175**
fronteras inferiores de la Tabla III.1 del manual (Emin en MeV, 3 cifras) con las
del fichero: **0 discrepancias** por encima del redondeo del manual. La extensión
sale con anchura constante de **1,000 MeV** entre **55,0 y 19,64 MeV**, y la
frontera superior de la parte VITAMIN-J en **19,64 MeV**, ambas exactamente como
las describe el texto del manual.

**B — contra el ¹H(n,γ) de la librería (independiente del manual).** El ¹H(n,γ)
es un absorbedor 1/v puro sin resonancias; con peso plano —el usado en el
procesado— su valor medio en cada grupo debe ser
σ̄ = 2σ₀√E₀ / (√E_sup + √E_inf). Ajustando σ₀ sobre los grupos 185–211:

- σ₀ = **0,3326 b**, frente al valor aceptado del ¹H a 2200 m/s de 0,3326 b
  (desviación −0,01 %);
- dispersión grupo a grupo del ajuste: **0,108 %**.

Es decir, la malla reproduce la librería en toda la región 1/v con una única
constante, y esa constante es el σ₀ físico. La malla no se ha ajustado a nada:
el acuerdo es una predicción cumplida.

**C — frontera de 20 MeV.** El ¹H(n,γ) de la librería es exactamente nulo en los
grupos 1–35 y no nulo desde el 36. La malla sitúa la frontera de los 20 MeV
justo entre 35 y 36. Coincidencia exacta, que confirma además el **orden
descendente** de la librería.

**D — efecto sobre el colapso.** Comparado el colapso con la malla real frente al
de la malla reconstruida por inversión del 1/v que usaba la versión 1 del script
(mismo espectro, mismo `XSBL.dat`):

| Reacción | Malla reconstruida | Malla real | dif |
|---|---|---|---|
| ¹³⁰Te(n,γ)¹³¹Te | 0,170523 | 0,170665 | +0,08 % |
| ¹³⁰Te(n,γ)¹³¹ᵐTe | 0,0074947 | 0,0075025 | +0,11 % |
| ¹³¹ᵐTe(n,γ)¹³²Te | 9,73737 | 9,74470 | +0,08 % |
| ¹³¹I(n,γ)¹³²I | 71,7049 | 71,7611 | +0,08 % |
| ¹²⁸Te(n,γ)¹²⁹Te | 0,160467 | 0,160533 | +0,04 % |
| ¹²⁷I(n,γ)¹²⁸I | 5,91294 | 5,91590 | +0,05 % |
| ¹⁹⁷Au(n,γ)¹⁹⁸Au *(resonante)* | 93,7555 | 93,8263 | +0,08 % |
| ¹¹⁵In(n,γ)¹¹⁶ᵐIn *(resonante)* | 125,95 | 126,03 | +0,06 % |
| ¹⁸¹Ta(n,γ)¹⁸²Ta *(resonante)* | 12,7147 | 12,7234 | +0,07 % |
| ⁵⁹Co(n,γ)⁶⁰Co *(resonante)* | 12,7385 | 12,7484 | +0,08 % |

Los canales resonantes se desplazan lo mismo que los 1/v, porque el 98,5 % del
flujo de este espectro está en grupos ≥ 190, donde el error de la reconstrucción
era menor del 0,4 %. **Resultado citable: para el espectro del Exp. 1 la
reconstrucción no sesgaba el resultado.** Aun así se adopta la malla real, que es
la citable, y la reconstrucción queda degradada a control.

*Limitación registrada de la reconstrucción, por si se recupera:* solo generaba
fronteras para los grupos 121–211 (E < 0,297 MeV) y su error crecía hasta el 4 %
hacia el keV. No es utilizable con espectros de componente epitérmica o rápida
dominante.

### Reserva abierta

La energía media que declara `FLUX.inf` (1,4717×10⁻⁴ MeV) **no se reproduce** con
esta malla: el cálculo directo da 2,0947×10⁻⁴ MeV con energía central de grupo,
y ninguna definición razonable de energía intragrupo (geométrica, de letargia,
fronteras) acerca las cifras — todas caen en 2,09–2,23×10⁻⁴ MeV. La hipótesis en
pie es que COLLAPS normaliza con `FTL` en vez de con el flujo total: Σφ·E / FTL
da 1,4537×10⁻⁴ MeV, a un 1,2 % del valor declarado. `FTL` (9,6114×10¹³, es decir
1,441 × el flujo total) no está documentado en el manual.

**Esto no afecta al `XSECTION.dat`.** El colapso es σ_eff = Σσ_g·φ_g / Σφ_g y en
esa expresión no interviene ninguna energía de grupo: solo las σ_g, que ya vienen
promediadas dentro de cada grupo en la librería. Verificado de forma directa: el
cálculo independiente en Python reproduce exactamente los valores impresos por
COLLAPS (0,170523 y 0,0074947 b, cifra a cifra). La energía media y `FTL` son
salida de diagnóstico.

*Vía de cierre disponible (`probe_collaps_mesh.py`):* con `ISTOP = 1` (tarjeta 9)
COLLAPS solo escribe `FLUX.inf`. Sondeando con flujo unidad en un único grupo se
lee la energía representativa que el propio código asigna a cada grupo, y con
ella la malla interna de COLLAPS, sin depender del manual ni de ENEA. Los
controles de escala (×2) y de aditividad fijan además qué es `FTL`.

**No es material de memoria.** La validación del colapso se documenta con la
comprobación que el propio COLLAPS ofrece (*flujo tras procesado = flujo real*) y
con el control físico σ(¹³⁰Te) ≈ σ₀·√π/2 contra la Tabla 3 del paper.

---

## 1.3 Espectro

Construido por componentes e integrado grupo a grupo sobre la malla real.

| Elemento | Valor | Fuente / naturaleza |
|---|---|---|
| Flujo térmico | 6,5×10¹³ n/cm²·s | Haffner et al., Exp. 1 — **dato** |
| Flujo epitérmico | 1,7×10¹² n/cm²·s | Haffner et al., Exp. 1 — **dato** |
| Forma térmica | maxwelliana de flujo φ(E) ∝ E·e^(−E/kT) | modelo estándar |
| kT | 0,0253 eV | energía térmica de referencia a 2200 m/s. Con el kT de la temperatura de la librería (293,16 K → 0,025263 eV) σ(¹³⁰Te) cambia **+0,03 %** |
| Forma epitérmica | 1/E | modelo estándar |
| Corte térmico/epitérmico | 0,5 eV | corte de cadmio — **convenio declarado** |
| Corte superior epitérmico | 10⁵ eV | **hipótesis del modelo**, no del paper. Variarlo entre 5×10⁴ y 2×10⁵ eV mueve σ(¹³⁰Te) menos del 0,02 % |
| Componente rápida | nula | **hipótesis del modelo** (posición térmica del MURR). Consecuencia declarable: este espectro **excluye las reacciones umbral** |
| Unidades y orden | n/cm²·s integrado por grupo (`FF = 0`), orden descendente (`NGROUP = −211`) | manual v.2008, tarjetas 5 y 7 |

Perfil resultante:

- flujo total **6,6700×10¹³ n/cm²·s**;
- **88,18 %** en el grupo 211 solo, es decir en [10⁻⁵; 0,1] eV;
- 97,67 % en los grupos 205–211 ([10⁻⁵; 1,445 eV]);
- 98,46 % en los grupos 190–211 ([10⁻⁵; 61,44 eV]).

*Nota terminológica para la memoria:* llamar «región térmica» a los grupos
205–211 es un convenio; conviene enunciarlo como E < 1,445 eV.

---

## 1.4 Controles de aceptación

| Control | Criterio | Estado |
|---|---|---|
| `IESF = ILIB` | ambos 12 | ✅ (verificado en el `FLUX.inf` del colapso anterior) |
| Flujo tras procesado = flujo real | 6,6700×10¹³ = 6,6700×10¹³ | ✅ (ídem) |
| σ(¹³⁰Te) colapsada ≈ σ₀·√π/2 | ver abajo | ✅ |
| Fracción térmica y energía media contra `FLUX.inf` | fracción ✅ · energía media ⚠️ (reserva del 1.2) | parcial |
| Reproducción independiente del colapso | Python vs COLLAPS, cifra a cifra | ✅ |

**Control físico σ₀ (material de memoria).** Con la malla real:

- σ(¹³⁰Te → ¹³¹Te) = **0,170665 b**
- σ(¹³⁰Te → ¹³¹ᵐTe) = **0,0075025 b**
- **TOTAL = 0,178167 b**

Deshaciendo el promedio maxwelliano de un absorbedor 1/v (√π/2 = 0,88623), el
colapso equivale a σ₀ = **0,2010 b**. Comparado con la Tabla 3 del paper
(«Discrepancies in literature over thermal cross-sections»): NNDC 2014 →
0,0106 + 0,184 = 0,195 b (los usados por Haffner); *Nuclides and Isotopes* 2010 →
0,197 b; Firestone 1998 → 0,29 b; JEFF-3.2 (2014) → 0,29 b. El valor del colapso
cae **dentro del rango de la propia tabla del paper**, un 3,1 % por encima del
adoptado por Haffner y muy por debajo de la dispersión entre evaluaciones (~50 %).

**Pendiente:** re-ejecutar COLLAPS con el `COLL.inp` regenerado sobre la malla
real y confirmar en el nuevo `FLUX.inf` los dos primeros controles, además de
verificar que el `XSECTION.dat` resultante imprime `1.70665E-01` y `7.50250E-03`.

---

## Cadena de ficheros

| Fichero | SHA-256 | Papel |
|---|---|---|
| `XSBL.dat` | `0b7841a3…cdc23b` | librería multigrupo de entrada |
| `vitaminj_plus_211_eV.txt` | `4c69bd5d…e955f8` | malla de energía (ENEA, validada contra manual) |
| `build_murr_flux.py` v.2 | `6d3a5a53…b0667c` | construye el espectro y escribe `COLL.inp` |
| `COLL.inp` | `38107dd7…6b8f6e` | entrada de COLLAPS |
| `XSECTION.dat` | *(calcular tras la ejecución)* | salida colapsada → ACAB |
| `probe_collaps_mesh.py` | *(auxiliar)* | sondeo `ISTOP=1` de la malla interna |

Versión anterior, conservada solo como referencia de la comparación D:
`COLL.inp` `615a4b4b…3e9bc7`, `XSECTION.dat` `5ccfc5ea…5b3e1c`,
`build_murr_flux.py` v.1 `ea317510…beb4047`.
